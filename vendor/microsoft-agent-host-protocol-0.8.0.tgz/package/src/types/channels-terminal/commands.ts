// Generated from types/*.ts — do not edit.
// Regenerate with: npm run generate:typescript

/**
 * Terminal Channel Commands — `createTerminal` and `disposeTerminal`.
 *
 * @module channels-terminal/commands
 */

import type { URI } from '../common/state.js';
import type { BaseParams } from '../common/commands.js';
import type { TerminalClaim } from './state.js';

// ─── createTerminal ──────────────────────────────────────────────────────────

/**
 * Creates a new terminal on the server.
 *
 * After creation, the client should subscribe to the terminal URI to receive
 * state updates. The server dispatches `root/terminalsChanged` to update the
 * root terminal list.
 *
 * @category Commands
 * @method createTerminal
 * @direction Client → Server
 * @messageType Request
 * @version 1
 */
export interface CreateTerminalParams extends BaseParams {
  /** Terminal URI (client-chosen). */
  channel: URI;
  /** Initial owner of the terminal */
  claim: TerminalClaim;
  /** Human-readable terminal name */
  name?: string;
  /** Initial working directory URI */
  cwd?: URI;
  /** Initial terminal width in columns */
  cols?: number;
  /** Initial terminal height in rows */
  rows?: number;
}

// ─── disposeTerminal ─────────────────────────────────────────────────────────

/**
 * Disposes a terminal and kills its process if still running.
 *
 * The server dispatches `root/terminalsChanged` to remove the terminal from
 * the root terminal list.
 *
 * @category Commands
 * @method disposeTerminal
 * @direction Client → Server
 * @messageType Request
 * @version 1
 */
export interface DisposeTerminalParams extends BaseParams {}
