// Generated from types/*.ts — do not edit.
// Regenerate with: npm run generate:typescript

/**
 * Automation Catalogue Channel Reducer.
 *
 * @module channels-automation/reducer
 */

import type { AutomationAction } from '../action-origin.generated.js';
import { ActionType } from '../common/actions.js';
import { softAssertNever } from '../common/reducer-helpers.js';
import type { AutomationCatalogState } from './state.js';

/** Pure reducer for automation catalogue state. */
export function automationReducer(state: AutomationCatalogState, action: AutomationAction, log?: (msg: string) => void): AutomationCatalogState {
  switch (action.type) {
    case ActionType.AutomationCreateRequested:
    case ActionType.AutomationUpdateRequested:
      return state;

    case ActionType.AutomationSet: {
      const idx = state.automations.findIndex(automation => automation.resource === action.automation.resource);
      if (idx < 0) {
        return {
          ...state,
          automations: [...state.automations, action.automation],
        };
      }
      const automations = state.automations.slice();
      automations[idx] = action.automation;
      return { ...state, automations };
    }

    case ActionType.AutomationRemoved: {
      const idx = state.automations.findIndex(automation => automation.resource === action.resource);
      if (idx < 0) {
        return state;
      }
      const automations = state.automations.slice();
      automations.splice(idx, 1);
      return { ...state, automations };
    }

    default:
      softAssertNever(action, log);
      return state;
  }
}
