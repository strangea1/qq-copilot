// Generated from types/*.ts — do not edit.
// Regenerate with: npm run generate:typescript

/**
 * Root Channel Actions — Mutations of the `ahp-root://` state.
 *
 * @module channels-root/actions
 */

import type { AgentInfo } from './state.js';
import type { TerminalInfo } from '../channels-terminal/state.js';
import { ActionType } from '../common/actions.js';

// ─── Root Actions ────────────────────────────────────────────────────────────

/**
 * Fired when available agent backends or their models change.
 *
 * @category Root Actions
 * @version 1
 */
export interface RootAgentsChangedAction {
  type: ActionType.RootAgentsChanged;
  /** Updated agent list */
  agents: AgentInfo[];
}

/**
 * Fired when the number of active sessions changes.
 *
 * @category Root Actions
 * @version 1
 */
export interface RootActiveSessionsChangedAction {
  type: ActionType.RootActiveSessionsChanged;
  /** Current count of active sessions */
  activeSessions: number;
}

/**
 * Fired when the list of known terminals changes.
 *
 * Full-replacement semantics: the `terminals` array replaces the previous
 * `terminals` entirely.
 *
 * @category Root Actions
 * @version 1
 */
export interface RootTerminalsChangedAction {
  type: ActionType.RootTerminalsChanged;
  /** Updated terminal list (full replacement) */
  terminals: TerminalInfo[];
}

/**
 * Fired when agent-host configuration values change.
 *
 * By default, the reducer merges the new values into `state.config.values`.
 * Set `replace` to `true` to replace all values instead of merging.
 *
 * @category Root Actions
 * @version 1
 * @clientDispatchable
 */
export interface RootConfigChangedAction {
  type: ActionType.RootConfigChanged;
  /** Updated config values */
  config: Record<string, unknown>;
  /** When `true`, replaces all config values instead of merging */
  replace?: boolean;
}
