// Generated from types/*.ts — do not edit.
// Regenerate with: npm run generate:typescript

/**
 * State Types — Aggregator shim that re-exports channel-organized state
 * declarations. New code should import directly from the per-channel files
 * under `types/common/`, `types/channels-root/`, `types/channels-session/`,
 * `types/channels-terminal/`, and `types/channels-changeset/`.
 *
 * @module state
 */

export * from './common/state.js';
export * from './channels-root/state.js';
export * from './channels-session/state.js';
export * from './channels-chat/state.js';
export * from './channels-canvas/state.js';
export * from './channels-terminal/state.js';
export * from './channels-changeset/state.js';
export * from './channels-annotations/state.js';
export * from './channels-otlp/state.js';
export * from './channels-resource-watch/state.js';
export * from './channels-automation/state.js';
export * from './channels-automation-run/state.js';
